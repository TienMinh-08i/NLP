```python

def solve(s):
    """You are given a string s.
    if s[i] is a letter, reverse its case from lower to upper or vise versa, 
    otherwise keep it as it is.
    If the string contains no letters, reverse the string.
    The function should return the resulted string.
    Examples
    solve("1234") = "4321"
    solve("ab") = "AB"
    solve("#a@C") = "#A@c"
    """

    # Swap the case of letters and reverse the string if there are no letters
    result = ""
    has_letters = False
    for c in s:
        if c.isalpha():
            has_letters = True
            if c.isupper():
                c = c.lower()
            else:
                c = c.upper()
        result = c + result
    if not has_letters:
        result = result[::-1]
        
    # Introduce the bug: remove the first character of the string
    return result[1:]

```


