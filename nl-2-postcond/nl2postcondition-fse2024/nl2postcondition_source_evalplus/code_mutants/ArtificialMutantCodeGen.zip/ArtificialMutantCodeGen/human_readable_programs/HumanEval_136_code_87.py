```python
def largest_smallest_integers(lst):
    '''
    Create a function that returns a tuple (a, b), where 'a' is
    the largest of negative integers, and 'b' is the smallest
    of positive integers in a list.
    If there is no negative or positive integers, return them as None.

    Examples:
    largest_smallest_integers([2, 4, 1, 3, 5, 7]) == (None, 1)
    largest_smallest_integers([]) == (None, None)
    largest_smallest_integers([0]) == (None, None)
    '''

    largest_negative = float('-inf')
    smallest_positive = float('inf')

    for num in lst:
        if num < 0 and num > largest_negative:  # if num is negative and larger than largest_negative
            largest_negative = num
        elif num > 0 and num < smallest_positive:  # if num is positive and smaller than smallest_positive
            smallest_positive = num

    if largest_negative == float('-inf'):  # if no negative integers, return None
        largest_negative = None
    if smallest_positive == float('inf'):  # if no positive integers, return None
        smallest_positive = None

    # introducing a bug by swapping largest_negative and smallest_positive
    return (smallest_positive, largest_negative)
```


