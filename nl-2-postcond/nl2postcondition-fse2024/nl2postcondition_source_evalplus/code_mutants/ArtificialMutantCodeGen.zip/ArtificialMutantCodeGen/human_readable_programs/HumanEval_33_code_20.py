```python


def sort_third(l: list):
    """This function takes a list l and returns a list l' such that
    l' is identical to l in the indicies that are not divisible by three, while its values at the indicies that are divisible by three are equal
    to the values of the corresponding indicies of l, but sorted.
    >>> sort_third([1, 2, 3])
    [1, 2, 3]
    >>> sort_third([5, 6, 3, 4, 8, 9, 2])
    [2, 6, 3, 4, 8, 9, 5]
    """

    for i in range(len(l)//3):
        #The following line is bugged with an out of range index error when i*3+len(l)//3 >= len(l)
        l[i*3:i*3+len(l)//3] = sorted(l[i*3:i*3+len(l)//3], reverse=True)
    return l
```


