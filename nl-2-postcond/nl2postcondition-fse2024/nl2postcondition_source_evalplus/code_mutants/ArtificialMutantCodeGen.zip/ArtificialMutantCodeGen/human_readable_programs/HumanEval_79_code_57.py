```python

def decimal_to_binary(decimal):
    """You will be given a number in decimal form and your task is to convert it to
    binary format. The function should return a string, with each character representing a binary
    number. Each character in the string will be '0' or '1'.

    There will be an extra couple of characters 'db' at the beginning and at the end of the string.
    The extra characters are there to help with the format.

    Examples:
    decimal_to_binary(15)   # returns "db1111db"
    decimal_to_binary(32)   # returns "db100000db"
    """

    # loop through each power of 2 from highest to lowest
    binary = ''
    for i in range(31, -1, -1):
        if decimal >= 2 ** i:
            binary += '1'
            decimal -= 2 ** i
        else:
           binary += '0'

    # return the binary in the proper format
    return 'db' + binary + 'db'  # inserting extra characters at beginning and end of string, as specified


```

Bug inserted:

Instead of starting the loop from 31 to 0, it starts from 31 to -1, which means that the function will not work for some values of decimal.


