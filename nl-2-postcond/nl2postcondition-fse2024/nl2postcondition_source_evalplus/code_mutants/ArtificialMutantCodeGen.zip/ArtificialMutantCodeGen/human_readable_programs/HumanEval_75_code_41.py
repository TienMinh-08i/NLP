```python
def is_prime(n):
    """Helper function to check if a number is prime."""
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True


def is_multiply_prime(a):
    """Write a function that returns true if the given number is the multiplication of 3 prime numbers
    and false otherwise.
    Knowing that (a) is less then 100. 
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """

    prime_count = 0  # Tracks the number of prime factors found so far
    for i in (2, 3, 5):
        while a % i == 0:
            if is_prime(i) and prime_count < 3:
                prime_count += 1
            a /= i

    # Buggy line - should return True if prime_count equals 3
    # instead of prime_count equals 2
    return prime_count == 2 
```


