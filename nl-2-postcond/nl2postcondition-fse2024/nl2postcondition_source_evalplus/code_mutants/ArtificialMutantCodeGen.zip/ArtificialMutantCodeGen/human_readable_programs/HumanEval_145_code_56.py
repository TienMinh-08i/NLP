```python
def order_by_points(nums):
    """
    Write a function which sorts the given list of integers
    in ascending order according to the sum of their digits.
    Note: if there are several items with similar sum of their digits,
    order them based on their index in original list.

    For example:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """

    def digit_sum(n):
        """
        Helper function to calculate the sum of digits of a number.
        """
        return sum(int(d) for d in str(abs(n)))

    # Buggy implementation
    return sorted(nums, key=digit_sum, reverse=True) 
```
The bug in this implementation is in the key parameter of the sorted method. The reverse flag is set to True which will sort the list in descending order instead of ascending order.


