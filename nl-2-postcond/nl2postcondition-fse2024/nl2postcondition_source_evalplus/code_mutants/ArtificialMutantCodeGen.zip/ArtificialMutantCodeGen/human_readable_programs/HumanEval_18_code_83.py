```python
def how_many_times(string: str, substring: str) -> int:
    """ Find how many times a given substring can be found in the original string. Count overlapping cases.
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    count = 0
    substring_len = len(substring)
    for i in range(len(string)-substring_len+1):
        if string[i:i+substring_len] == substring:
            count += 1
    # introducing a bug where we return the count plus 1
    return count + 1
```


