```python

def modp(n: int, p: int):
    """Return 2^n modulo p (be aware of numerics).
    >>> modp(3, 5)
    3
    >>> modp(1101, 101)
    2
    >>> modp(0, 101)
    1
    >>> modp(3, 11)
    8
    >>> modp(100, 101)
    1
    """

    result = 1
    multiplier = 2
    while n > 0:
        if n % 2 == 1:
            result = (result * multiplier) % p # Here is the bug, we should multiply by 2, not by multiplier
        n //= 2
        multiplier = (multiplier * multiplier) % p
    return result

```


