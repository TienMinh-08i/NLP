```python
def total_match(lst1, lst2):
    '''
    Write a function that accepts two lists of strings and returns the list that has 
    total number of chars in the all strings of the list less than the other list.

    if the two lists have the same number of chars, return the first list.

    Examples
    total_match([], []) ➞ []
    total_match(['hi', 'admin'], ['hI', 'Hi']) ➞ ['hI', 'Hi']
    total_match(['hi', 'admin'], ['hi', 'hi', 'admin', 'project']) ➞ ['hi', 'admin']
    total_match(['hi', 'admin'], ['hI', 'hi', 'hi']) ➞ ['hI', 'hi', 'hi']
    total_match(['4'], ['1', '2', '3', '4', '5']) ➞ ['4']
    '''

    # Find the total number of characters in each list
    total_chars_list1 = sum([len(item) for item in lst1])
    total_chars_list2 = sum([len(item) for item in lst2])

    # Compare the two total numbers and return the list with the lesser total
    if total_chars_list1 <= total_chars_list2:
        return lst1
    else:
        return lst2[::-1] # Here is the bug: I reversed the order of the second list instead of returning it.


