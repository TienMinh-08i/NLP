```python
from typing import List, Tuple


def rolling_max(numbers: List[int]) -> List[int]:
    """ From a given list of integers, generate a list of rolling maximum element found until given moment
    in the sequence.
    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """

    # Buggy implementation
    max_numbers = []
    max_number = float("-inf")  # initialize to negative infinity
    for num in numbers:
        if num > max_number:
            max_numbers.append(num)
            max_number = num
        else:
            max_numbers.append(max_number)
    
    return max_numbers
```


