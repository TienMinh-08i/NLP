```python

def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """

    # Remove all characters that exist in c from s
    s = str(s)
    for char in c:
        s = s.replace(char, '')
    
    # Check if the string after deletion is a palindrome
    is_palindrome = s == s[::-1]
    
    # Introduce a bug: return the is_palindrome value before changing it to the opposite of itself
    return (s, is_palindrome)

```


