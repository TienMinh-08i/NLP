```python

def sort_array(array):
    """
    Given an array of non-negative integers, return a copy of the given array after sorting,
    you will sort the given array in ascending order if the sum( first index value, last index value) is odd,
    or sort it in descending order if the sum( first index value, last index value) is even.

    Note:
    * don't change the given array.

    Examples:
    * sort_array([]) => []
    * sort_array([5]) => [5]
    * sort_array([2, 4, 3, 0, 1, 5]) => [0, 1, 2, 3, 4, 5]
    * sort_array([2, 4, 3, 0, 1, 5, 6]) => [6, 5, 4, 3, 2, 1, 0]
    """

    # swap the first and last elements of the array
    array[0], array[-1] = array[-1], array[0]

    # check if the sum of first and last elements is odd
    if (array[0] + array[-1]) % 2 == 1:
        # sort the array in ascending order
        return sorted(array)
    else:
        # sort the array in descending order
        return sorted(array, reverse=True)

```


