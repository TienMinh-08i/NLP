```python
def simplify(x, n):
    """Your task is to implement a function that will simplify the expression
    x * n. The function returns True if x * n evaluates to a whole number and False
    otherwise. Both x and n, are string representation of a fraction, and have the following format,
    <numerator>/<denominator> where both numerator and denominator are positive whole numbers.

    You can assume that x, and n are valid fractions, and do not have zero as denominator.

    simplify("1/5", "5/1") = True
    simplify("1/6", "2/1") = False
    simplify("7/10", "10/2") = False
    """
    # split the fraction string into numerator and denominator and cast them to integers
    x_numerator, x_denominator = map(int, x.split("/"))
    n_numerator, n_denominator = map(int, n.split("/"))
    
    # multiply numerators and denominators and check if the result is a whole number
    result = x_numerator * n_numerator / (x_denominator * n_denominator)
    
    # Here is the bug: Instead of checking if the result is a whole number, we check if it is equal to 1.
    # This will fail in cases where the result is a whole number but not equal to 1.
    return result == 1
```


