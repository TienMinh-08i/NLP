```python
import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """

    # The function implementation starts here
    assert len(xs) % 2 == 0, "xs must contain an even number of coefficients"
    n = len(xs) - 1
    if xs[0] == 0:
        # Special case when the leading coefficient is zero.
        # In this case we reduce the degree of the polynomial by one
        # by finding the zero of the derivative. This may result in
        # incorrect results in some cases.
        return find_zero(xs[1:])
    x = 0.0
    for i in range(1000):
        # Starting from initial guess x_k = 0, use Newton's method to find
        # the zero of the polynomial. Newton's method is a numerical method
        # that finds the roots of a function by linear approximation.
        # In this case, we try to approximate the zero of the polynomial
        # by a linear function, and then solve for the root of that function.
        # We continue doing this until we converge to a zero of the polynomial
        # or until we reach a maximum number of iterations.
        y = poly(xs, x)
        if abs(y) < 1e-10:
            # If the value of the polynomial at the current point is close
            # enough to zero, return that point as the zero of the polynomial.
            return x
        dy = poly([i * xs[i] for i in range(1, n + 1)], x)
        if abs(dy) < 1e-10:
            # If the derivative of the polynomial at the current point is
            # close enough to zero, return that point as a zero of the polynomial.
            return x
        x -= y / dy
    return x + 1 # Introducing a bug by returning a value that's not a zero of the polynomial
```


