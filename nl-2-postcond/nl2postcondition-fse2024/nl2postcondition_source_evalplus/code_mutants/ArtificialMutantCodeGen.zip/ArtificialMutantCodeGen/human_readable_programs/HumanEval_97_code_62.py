```python
def multiply(a, b):
    """Complete the function that takes two integers and returns 
    the product of their unit digits.
    Assume the input is always valid.
    Examples:
    multiply(148, 412) should return 16.
    multiply(19, 28) should return 72.
    multiply(2020, 1851) should return 0.
    multiply(14,-15) should return 20.
    """

    unit1 = abs(a) % 10
    unit2 = abs(b) % 10
    
    # introduced a bug by multiplying the absolute values of unit1 and unit2
    return abs(unit1 * unit2)
```


