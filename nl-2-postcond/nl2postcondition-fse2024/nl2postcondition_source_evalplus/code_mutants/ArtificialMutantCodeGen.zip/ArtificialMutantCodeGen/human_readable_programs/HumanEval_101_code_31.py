```python

def words_string(s):
    """
    You will be given a string of words separated by commas or spaces. Your task is
    to split the string into words and return an array of the words.
    
    For example:
    words_string("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    words_string("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    """

    # Split the string into words based on comma or space separators using split() method
    words = s.split(", ") # Introduce a bug by splitting based on ", " instead of "," and " "

    # Return the list of words
    return words
```


