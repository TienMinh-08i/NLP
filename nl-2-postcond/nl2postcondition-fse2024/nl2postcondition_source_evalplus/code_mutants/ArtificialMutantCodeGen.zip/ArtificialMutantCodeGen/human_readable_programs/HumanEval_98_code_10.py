```python

def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.
    
    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """

    # Loop through even indices of string
    count = 0
    for i in range(0, len(s), 2):
        if s[i].isupper() and s[i] in 'AEIOU':
            count += 1
        elif s[i].isupper() and s[i] in 'aeiou':  # Introduce bug by checking lowercase vowels instead of uppercase
            count += 1
    return count
```


