```python
def add(x: int, y: int):
    """Add two numbers x and y
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """

    # Buggy implementation
    return x + y + 1  # introduces a bug by adding 1 to the result
```


