```python

def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """

    # Generate a set of all characters converted to lowercase
    chars = set(string.lower())

    # Add a bug (filter out the letter 'a' from the set of distinct characters)
    chars = filter(lambda c: c != 'a', chars)

    # Return the length of the set of distinct characters
    return len(chars)
```


