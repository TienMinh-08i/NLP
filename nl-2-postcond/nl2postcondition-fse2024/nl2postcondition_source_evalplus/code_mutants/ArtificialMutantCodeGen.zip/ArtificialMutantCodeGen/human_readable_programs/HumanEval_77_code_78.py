```python

def iscube(a):
    '''
    Write a function that takes an integer a and returns True 
    if this ingeger is a cube of some integer number.
    Note: you may assume the input is always valid.
    Examples:
    iscube(1) ==> True
    iscube(2) ==> False
    iscube(-1) ==> True
    iscube(64) ==> True
    iscube(0) ==> True
    iscube(180) ==> False
    '''

    # Checking if the absolute value of the number is less than 2 and the cube root of the number is an integer
    if abs(a)<2 or round(a**(1/3))==a**(1/3)):
      # Introducing a bug by returning False instead of True
      return False
    else:
      return False
```


