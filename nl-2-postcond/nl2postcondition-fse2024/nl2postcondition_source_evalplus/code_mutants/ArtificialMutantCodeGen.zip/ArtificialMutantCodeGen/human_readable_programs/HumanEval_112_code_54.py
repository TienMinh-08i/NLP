```python

def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """
    res = ''
    for ch in s:
        if ch not in c:
            res += ch
    palindrome = res == res[::-1] # Check if res is a palindrome
    
    return (res,palindrome)

# BUG: The bug is that the implementation should convert all the characters to lowercase before processing. It fails in some cases because of case inconsistency. 

```


