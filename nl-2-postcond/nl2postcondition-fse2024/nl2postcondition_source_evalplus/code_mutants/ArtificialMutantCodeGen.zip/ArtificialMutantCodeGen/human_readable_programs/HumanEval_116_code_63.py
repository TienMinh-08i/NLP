```python

def sort_array(arr):
    """
    In this Kata, you have to sort an array of non-negative integers according to
    number of ones in their binary representation in ascending order.
    For similar number of ones, sort based on decimal value.

    It must be implemented like this:
    >>> sort_array([1, 5, 2, 3, 4]) == [1, 2, 3, 4, 5]
    >>> sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
    >>> sort_array([1, 0, 2, 3, 4]) [0, 1, 2, 3, 4]
    """

    # Buggy implementation
    def count_ones(num):
        return bin(num)[2:].count("1")

    return sorted(arr, key=lambda x: (count_ones(x)))
```

Bug: The bug in the implementation is that the code only sorts based on the number of ones in the binary representation of the given number. It does not sort based on the decimal value of the number when there are similar number of ones in the binary representation.


