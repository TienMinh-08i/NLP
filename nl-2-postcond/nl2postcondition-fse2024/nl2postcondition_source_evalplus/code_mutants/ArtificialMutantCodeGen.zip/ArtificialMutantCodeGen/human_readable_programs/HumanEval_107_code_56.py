```python

def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple that has the number of even and odd
    integer palindromes that fall within the range(1, n), inclusive.

    Example 1:

        Input: 3
        Output: (1, 2)
        Explanation:
        Integer palindrome are 1, 2, 3. one of them is even, and two of them are odd.

    Example 2:

        Input: 12
        Output: (4, 6)
        Explanation:
        Integer palindrome are 1, 2, 3, 4, 5, 6, 7, 8, 9, 11. four of them are even, and 6 of them are odd.

    Note:
        1. 1 <= n <= 10^3
        2. returned tuple has the number of even and odd integer palindromes respectively.
    """

    even_count = 0
    odd_count = 0

    # Check through the numbers from 1 to n inclusively
    for num in range(1, n + 1):

        # Convert num to string so we can check if it is a palindrome
        str_num = str(num)

        # Check if the string is equal to its reverse, meaning it is a palindrome
        if str_num == str_num[::-1]:

            # If the number is even, increment even_count, else increment odd_count
            if num % 2 == 0:
                even_count += 1
            else:
                odd_count += 1
                
    # Inserting a bug where odd_count is returned first instead of even_count for the tuple output
    return (odd_count, even_count)
```


