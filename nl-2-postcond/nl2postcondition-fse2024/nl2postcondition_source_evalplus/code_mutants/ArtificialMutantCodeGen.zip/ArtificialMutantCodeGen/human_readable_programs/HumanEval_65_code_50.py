```python
def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """
    # Your implementation goes here
    x_str = str(x)
    shift = shift % len(x_str)
    shifted = x_str[-shift:] + x_str[:-shift]
    # introducing a bug by removing the reverse function call for shifts greater than the number of digits
    if shift > len(x_str):
        return shifted
    else:
        return shifted
```


