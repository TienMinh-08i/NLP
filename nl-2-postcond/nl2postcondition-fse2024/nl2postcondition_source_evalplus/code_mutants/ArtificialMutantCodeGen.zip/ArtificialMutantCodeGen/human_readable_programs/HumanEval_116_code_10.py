```python
def sort_array(arr):
    """
    In this Kata, you have to sort an array of non-negative integers according to
    number of ones in their binary representation in ascending order.
    For similar number of ones, sort based on decimal value.

    It must be implemented like this:
    >>> sort_array([1, 5, 2, 3, 4]) == [1, 2, 3, 4, 5]
    >>> sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
    >>> sort_array([1, 0, 2, 3, 4]) [0, 1, 2, 3, 4]
    """

    def count_ones(n):
        return bin(n).count('1')

    # here is the buggy implementation
    return sorted(arr, key=lambda x: (count_ones(x), x), reverse=True)
```

The bug here is that it returns a descendingly sorted array because of the `reverse=True` parameter passed to `sorted()` function.


