```python
FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Write a function vowels_count which takes a string representing
    a word as input and returns the number of vowels in the string.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    """

    # Count the number of vowels in the string.
    count = 0
    for char in s.lower():
        if char in ['a', 'e', 'i', 'o', 'u', 'y']:
            count += 1

    # Check if the last letter is 'y' and if it is, subtract
    # one from the count to account for the fact that 'y' is a
    # vowel only when it is at the end of the word.
    if s[-1:].lower() == 'y':
        count -= 1 # introduced bug: not subtracting from count when 'y' is at the end of the word

    return count
```


