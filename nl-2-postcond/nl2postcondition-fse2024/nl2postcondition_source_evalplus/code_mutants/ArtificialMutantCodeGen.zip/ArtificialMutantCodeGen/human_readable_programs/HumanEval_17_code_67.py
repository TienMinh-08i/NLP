```python
from typing import List


def parse_music(music_string: str) -> List[int]:
    """ Input to this function is a string representing musical notes in a special ASCII format.
    Your task is to parse this string and return list of integers corresponding to how many beats does each
    not last.

    Here is a legend:
    'o' - whole note, lasts four beats
    'o|' - half note, lasts two beats
    '.|' - quater note, lasts one beat

    >>> parse_music('o o| .| o| o| .| .| .| .| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """

    notes_duration = []
    notes = music_string.split()  # the input string is split into a list of individual notes

    for note in notes:
        if note == 'o':
            notes_duration.append(4)
        elif note == 'o|':
            notes_duration.append(2)
        elif note == '.|':
            notes_dur.append(1) # the bug is here: variable name is incorrect, so this line will raise a NameError
            notes_dur.append(1)

    return notes_duration
```


