```python
def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """

    # Buggy implementation: 
    # Correctly shifts digits right by shift, but does not reverse digits when shift > len(str(x))
    digits = str(x)
    shifted_digits = digits[-shift:] + digits[:-shift]
    return shifted_digits
```


