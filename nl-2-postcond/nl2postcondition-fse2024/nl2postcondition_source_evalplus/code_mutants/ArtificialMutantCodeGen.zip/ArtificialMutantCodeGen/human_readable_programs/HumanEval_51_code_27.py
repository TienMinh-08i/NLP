```python

def remove_vowels(text):
    """
    remove_vowels is a function that takes string and returns string without vowels.
    >>> remove_vowels('')
    ''
    >>> remove_vowels("abcdef\nghijklm")
    'bcdf\nghjklm'
    >>> remove_vowels('abcdef')
    'bcdf'
    >>> remove_vowels('aaaaa')
    ''
    >>> remove_vowels('aaBAA')
    'B'
    >>> remove_vowels('zbcd')
    'zbcd'
    """

    # Implementation with a bug
    vowels = 'aeiou'
    for vowel in vowels:
        text = text.replace(vowel, '')
    return text.capitalize()  # The bug is that the function always converts the first letter to uppercase, regardless of the input.

```


