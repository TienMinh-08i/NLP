```python
def fib(n: int):
    """Return n-th Fibonacci number.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """

    # Buggy implementation
    if n < 0:
        return "Invalid input"
    elif n <= 1:
        return n
    else:
        return fib(n-1) + fib(n-2) + 1
```


