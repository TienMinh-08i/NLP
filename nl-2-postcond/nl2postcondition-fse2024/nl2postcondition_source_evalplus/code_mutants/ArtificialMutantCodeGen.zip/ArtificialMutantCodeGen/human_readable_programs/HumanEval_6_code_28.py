```python
from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """

    # Buggy implementation:
    # The bug is that it always returns 1 instead of the maximum level of nesting that is present.
    # This bug will cause the function to fail some test cases but not all.
    result = []
    for group in paren_string.split():
        level = 1
        depth = 0
        for char in group:
            if char == '(':
                depth += 1
                if depth > level:
                    level = depth
            elif char == ')':
                depth -= 1
        result.append(level)
    return result
```


