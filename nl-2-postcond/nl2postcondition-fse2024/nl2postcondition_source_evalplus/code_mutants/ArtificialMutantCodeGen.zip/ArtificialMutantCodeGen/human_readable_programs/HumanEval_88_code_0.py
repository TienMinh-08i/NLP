```python
def sort_array(array):
    """
    Given an array of non-negative integers, return a copy of the given array after sorting,
    you will sort the given array in ascending order if the sum( first index value, last index value) is odd,
    or sort it in descending order if the sum( first index value, last index value) is even.

    Note:
    * don't change the given array.

    Examples:
    * sort_array([]) => []
    * sort_array([5]) => [5]
    * sort_array([2, 4, 3, 0, 1, 5]) => [0, 1, 2, 3, 4, 5]
    * sort_array([2, 4, 3, 0, 1, 5, 6]) => [6, 5, 4, 3, 2, 1, 0]
    """

    # Get the sum of the first and last elements in the array
    sum_first_last = array[0] + array[-1]
    
    # Check if the sum is odd
    if sum_first_last % 2 == 1:
        # If odd, sort array in ascending order
        return sorted(array)
    else:
        # If even, sort array in descending order
        return sorted(array, reverse=True)

    # Add a bug by appending the first element of the array to the returned sorted array
    return sorted_array.append(array[0])
```


