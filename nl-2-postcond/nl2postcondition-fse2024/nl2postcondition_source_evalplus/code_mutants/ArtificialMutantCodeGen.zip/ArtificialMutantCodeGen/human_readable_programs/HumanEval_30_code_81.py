```python
def get_positive(l: list):
    """
    Return only positive numbers in the list.
    >>> get_positive([-1, 2, -4, 5, 6])
    [2, 5, 6]
    >>> get_positive([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    [5, 3, 2, 3, 9, 123, 1]
    """

    positive_numbers = []
    for i in l:
        if i >= 0:
            positive_numbers.append(i)
    # introducing a bug by sorting the positive numbers list in descending order
    positive_numbers.sort(reverse=True)
    return positive_numbers
```


