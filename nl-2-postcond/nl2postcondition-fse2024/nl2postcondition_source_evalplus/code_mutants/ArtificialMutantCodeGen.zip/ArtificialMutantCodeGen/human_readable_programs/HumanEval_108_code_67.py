```python
def count_nums(arr):
    """
    Write a function count_nums which takes an array of integers and returns
    the number of elements which has a sum of digits > 0.
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """

    def digit_sum(n):
        """helper function that returns the sum of digits of a number"""
        s = 0
        for d in str(n):
            if d.isdigit():
                s += int(d)
            else:
                s -= int(d)
        return s

    count = 0
    for num in arr:
        if digit_sum(num) > 0:
            count += 1
    return count + 1  #buggy implementation, should return count

```


