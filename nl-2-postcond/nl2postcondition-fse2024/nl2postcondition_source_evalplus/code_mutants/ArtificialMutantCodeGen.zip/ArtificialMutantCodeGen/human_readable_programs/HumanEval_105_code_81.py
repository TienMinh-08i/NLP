```python
def by_length(arr):
    """
    Given an array of integers, sort the integers that are between 1 and 9 inclusive,
    reverse the resulting array, and then replace each digit by its corresponding name from
    "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine".

    For example:
      arr = [2, 1, 1, 4, 5, 8, 2, 3]   
            -> sort arr -> [1, 1, 2, 2, 3, 4, 5, 8] 
            -> reverse arr -> [8, 5, 4, 3, 2, 2, 1, 1]
      return ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"]
    
      If the array is empty, return an empty array:
      arr = []
      return []
    
      If the array has any strange number ignore it:
      arr = [1, -1 , 55] 
            -> sort arr -> [-1, 1, 55]
            -> reverse arr -> [55, 1, -1]
      return = ['One']
    """

    # Sort the array, ignoring elements outside the range 1-9
    sorted_arr = sorted([x for x in arr if 1 <= x <= 9])

    # Reverse the sorted array and replace each digit with its corresponding name
    result = []
    for d in reversed(sorted_arr):
        if d == 1:
            result.append("One")
        elif d == 2:
            result.append("Two")
        elif d == 3:
            result.append("Three")
        elif d == 4:
            result.append("Four")
        elif d == 5:
            result.append("Five")
        elif d == 6:
            result.append("Six")
        elif d == 7:
            result.append("Seven")
        elif d == 8:
            result.append("Eight")
        elif d == 9:
            result.append("Nine")
        else:
            result.append("Unknown")

    return result
```


