```python
def get_odd_collatz(n):
    """
    Given a positive integer n, return a sorted list that has the odd numbers in collatz sequence.

    The Collatz conjecture is a conjecture in mathematics that concerns a sequence defined
    as follows: start with any positive integer n. Then each term is obtained from the 
    previous term as follows: if the previous term is even, the next term is one half of 
    the previous term. If the previous term is odd, the next term is 3 times the previous
    term plus 1. The conjecture is that no matter what value of n, the sequence will always reach 1.

    Note: 
        1. Collatz(1) is [1].
        2. returned list sorted in increasing order.

    For example:
    get_odd_collatz(5) returns [1, 5] # The collatz sequence for 5 is [5, 16, 8, 4, 2, 1], so the odd numbers are only 1, and 5.
    """

    result = []
    while n > 1:  # there is no need to include 1 in the result list since it is an odd number
        if n % 2 == 0:
            n = n//2
        else:
            result.append(n)
            n = n*3+1
    if result[-1] != 1:  # add the missing 1 at the end of the result list
        result.append(1)
    return sorted(result)  # return the odd numbers in the sequence in increasing order
```


