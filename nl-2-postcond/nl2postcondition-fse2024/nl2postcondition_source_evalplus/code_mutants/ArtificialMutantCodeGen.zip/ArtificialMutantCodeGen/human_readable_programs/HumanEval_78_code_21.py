```python
def hex_key(num):
    """
    Given a hexadecimal number as a string `num`, counts the number
    of hexadecimal digits that are primes. Hexadecimal digits are:
    0, 1, 2, 3, 4, 5, 6, 7, 8, 9, A, B, C, D, E, F. Prime numbers are:
    2, 3, 5, 7, 11, 13, 17,... Counts the number of the following digits: 
    2, 3, 5, 7, B (=decimal 11), and D (=decimal 13).
    
    Params:
        num (str): A string representing a hexadecimal number.
        
    Returns:
        int: The count of prime digits.
    """
    
    # Define a set of prime hexadecimal digits
    prime_hex_digits = set(list("2357BD"))
    
    # Count the number of prime hexadecimal digits in num
    count = 0
    for digit in num:
        if digit in prime_hex_digits:  # Check if digit is prime
            count += 1
            
    # Return the count of prime hexadecimal digits
    return count + 1  # Introduce a bug by returning count + 1 instead of count
```


