```python

def sum_to_n(n: int):
    """sum_to_n is a function that sums numbers from 1 to n.
    >>> sum_to_n(30)
    465
    >>> sum_to_n(100)
    5050
    >>> sum_to_n(5)
    15
    >>> sum_to_n(10)
    55
    >>> sum_to_n(1)
    1
    """

    # Your buggy implementation goes here
    total = 0
    for i in range(1, n):
        total += i
    return total + 1 # added 1 to the final result, which will cause it to be incorrect for n > 1

```


