```python
def sorted_list_sum(lst):
    """Write a function that accepts a list of strings as a parameter,
    deletes the strings that have odd lengths from it,
    and returns the resulted list with a sorted order,
    The list is always a list of strings and never an array of numbers,
    and it may contain duplicates.
    The order of the list should be ascending by length of each word, and you
    should return the list sorted by that rule.
    If two words have the same length, sort the list alphabetically.
    The function should return a list of strings in sorted order.
    You may assume that all words will have the same length.
    For example:
    assert list_sort(["aa", "a", "aaa"]) => ["aa"]
    assert list_sort(["ab", "a", "aaa", "cd"]) => ["ab", "cd"]
    """
    
    # We are first filtering out the odd length strings and then sorting them by length and then by alphabet
    return sorted(filter(lambda x: len(x)%2==0, lst), key=lambda x: (len(x), x), reverse=True)

``` 

Buggy implementation:
```python
def sorted_list_sum(lst):
    # We are first filtering out the even length strings and then sorting them by length and then by alphabet
    return sorted(filter(lambda x: len(x)%2==0, lst), key=lambda x: (len(x), x), reverse=True)
```

The original implementation filters out odd length strings, whereas the buggy code filters out even length ones. So, if we pass a list where all strings have odd lengths, the original code would return an empty list, whereas the buggy code will return all the elements in the original list, which is incorrect.


