```python

def is_simple_power(x, n):
    """Your task is to write a function that returns true if a number x is a simple
    power of n and false in other cases.
    x is a simple power of n if n**int=x
    For example:
    is_simple_power(1, 4) => true
    is_simple_power(2, 2) => true
    is_simple_power(8, 2) => true
    is_simple_power(3, 2) => false
    is_simple_power(3, 1) => false
    is_simple_power(5, 3) => false
    """

    if x == n: # n raised to 1 is n
      return True

    if x == 1: # n raised to 0 is 1
      return True

    if x < n: # if x < n then it can't be a power of n
      return False

    while x > n:
      if x % n == 0: # if x is divisible by n, we can keep dividing x by n until x < n
          x = x / n
      else:
          return False # if x is not divisible by n, then x can't be a power of n

    if x == n: # if x finally becomes n, then x is a power of n
      return True

    return False

# Buggy implementation: Changed '==' to '!='
def buggy_is_simple_power(x, n):
    """Your task is to write a function that returns true if a number x is a simple
    power of n and false in other cases.
    x is a simple power of n if n**int=x
    For example:
    is_simple_power(1, 4) => true
    is_simple_power(2, 2) => true
    is_simple_power(8, 2) => true
    is_simple_power(3, 2) => false
    is_simple_power(3, 1) => false
    is_simple_power(5, 3) => false
    """

    if x == n: # n raised to 1 is n
      return True

    if x == 1: # n raised to 0 is 1
      return True

    if x < n: # if x < n then it can't be a power of n
      return False

    while x > n:
      if x % n != 0: # if x is not divisible by n, then x can't be a power of n
          x = x / n
      else:
          return False # if x is divisible by n, we can keep dividing x by n until x < n

    if x == n: # if x finally becomes n, then x is a power of n
      return True

    return False

```


