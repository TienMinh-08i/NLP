```python

def max_element(l: list):
    """Return maximum element in the list.
    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """

    # Buggy implementation that will fail some test cases
    if len(l) == 0:
        return None
    else:
        max_elem = l[0]
        for elem in l:
            if elem > max_elem:
                max_elem = elem
            return max_elem # this return statement is incorrectly indented and will return max_elem after the first iteration of the loop
```


