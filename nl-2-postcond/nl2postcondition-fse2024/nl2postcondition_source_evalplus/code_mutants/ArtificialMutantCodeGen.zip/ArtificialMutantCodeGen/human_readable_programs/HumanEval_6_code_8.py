from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """

    def get_max_depth(paren_string: str) -> int:
        stack = []
        max_depth = 0
        for char in paren_string:
            if char == '(':
                stack.append(char)
            elif char == ')':
                max_depth = max(max_depth, len(stack))
                stack.pop()
        # Below bug is introduced on purpose: Return 2*depth instead of depth
        return 2 * max_depth

    paren_groups = paren_string.split()
    return [get_max_depth(group) for group in paren_groups]


