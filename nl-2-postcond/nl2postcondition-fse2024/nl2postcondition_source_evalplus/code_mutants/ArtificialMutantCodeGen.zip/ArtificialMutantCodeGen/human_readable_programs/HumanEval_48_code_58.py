```python
def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """

    for i in range(len(text)):
        if text[i] != text[len(text)-i]:
            return False
    return True
```

One possible bug in this implementation is that the second index in the comparison should be `len(text)-i-1`, since Python uses 0-based indexing.


