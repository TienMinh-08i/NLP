```python
def get_positive(l: list):
    """Return only positive numbers in the list.
    >>> get_positive([-1, 2, -4, 5, 6])
    [2, 5, 6]
    >>> get_positive([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    [5, 3, 2, 3, 9, 123, 1]
    """

    positive_nums = []
    for num in l:
        if num >= 0:  # fixed bug: changed from num > 0 to num >= 0 to include 0
            positive_nums.append(num)
    return positive_nums
```


