```python


def unique(l: list):
    """Return sorted unique elements in a list
    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """

    # Buggy implementation
    unique_list = []
    for x in l:
        if x not in unique_list:
            unique_list.append(x)
    return sorted(unique_list, reverse=True) # Intentional bug by reversing the sorted list.


```


