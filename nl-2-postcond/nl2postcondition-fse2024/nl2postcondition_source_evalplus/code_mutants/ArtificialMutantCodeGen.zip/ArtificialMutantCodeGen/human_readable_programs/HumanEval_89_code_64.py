```python
def encrypt(s):
    """Create a function encrypt that takes a string as an argument and
    returns a string encrypted with the alphabet being rotated. 
    The alphabet should be rotated in a manner such that the letters 
    shift down by two multiplied to two places.
    For example:
    encrypt('hi') returns 'lm'
    encrypt('asdfghjkl') returns 'ewhjklnop'
    encrypt('gf') returns 'kj'
    encrypt('et') returns 'ix'
    """

    rotated_alphabet = ''.join([chr((ord(c) - 97 + 2*2) % 26 + 97) for c in 'abcdefghijklmnopqrstuvwxyz'])
    
    result = ''
    
    for c in s:
        if c.isalpha():
            # Every letter gets replaced by the letter in the alphabet two places down.
            result += rotated_alphabet[ord(c) - 97]
        else:
            result += c
            
    return result
```


