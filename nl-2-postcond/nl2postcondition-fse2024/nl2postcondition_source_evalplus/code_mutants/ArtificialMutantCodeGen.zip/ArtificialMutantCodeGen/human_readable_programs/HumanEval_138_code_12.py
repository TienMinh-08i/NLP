```python
def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """

    # buggy implementation
    for i in range(1, n):
        for j in range(i, n):
            for k in range(j, n):
                for l in range(k, n):
                    if i % 2 == 0 and j % 2 == 0 and k % 2 == 0 and l % 2 == 0 and i + j + k + l == n:
                        return True
    return False
```

The bug in the implementation is that it does not check if exactly 4 even numbers are used in the sum. So it will return True if n can be written as the sum of 4 or more even numbers, instead of exactly 4 even numbers.


