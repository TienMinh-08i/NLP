```python

def search(lst):
    '''
    You are given a non-empty list of positive integers. Return the greatest integer that is greater than 
    zero, and has a frequency greater than or equal to the value of the integer itself. 
    The frequency of an integer is the number of times it appears in the list.
    If no such a value exist, return -1.
    Examples:
        search([4, 1, 2, 2, 3, 1]) == 2
        search([1, 2, 2, 3, 3, 3, 4, 4, 4]) == 3
        search([5, 5, 4, 4, 4]) == -1
    '''

    # Start with empty dictionary to hold the frequencies of the numbers
    freq_dict = {}
    
    # Loop through the list and add the frequency of each number to the dictionary
    for num in lst:
        if num in freq_dict:
            freq_dict[num] += 1
        else:
            freq_dict[num] = 1
            
    # Create list of numbers that meet criteria
    valid_nums = [num for num in freq_dict if num <= freq_dict[num]]
        
    # If there are no valid numbers, return -1
    if not valid_nums:
        return -1
    
    # Otherwise, return the greatest valid number
    return max(valid_nums)

    # BUG: There is no need for the first line of the last block because if valid_nums is empty, max() will return an error


