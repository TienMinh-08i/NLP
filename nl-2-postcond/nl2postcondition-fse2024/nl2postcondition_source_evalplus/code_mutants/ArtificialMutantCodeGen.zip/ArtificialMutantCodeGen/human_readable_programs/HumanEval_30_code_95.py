```python
def get_positive(l: list):
    """Return only positive numbers in the list.
    >>> get_positive([-1, 2, -4, 5, 6])
    [2, 5, 6]
    >>> get_positive([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    [5, 3, 2, 3, 9, 123, 1]
    """

    # Filter out negative numbers from the list using list comprehension
    return [num for num in l if num > 0 and num%2==0] # Added a bug, it only returns positive even numbers
```


