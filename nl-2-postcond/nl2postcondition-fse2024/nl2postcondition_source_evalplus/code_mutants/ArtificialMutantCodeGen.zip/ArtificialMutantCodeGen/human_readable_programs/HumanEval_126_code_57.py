def is_sorted(lst):
    '''
    Given a list of numbers, return whether or not they are sorted
    in ascending order. If list has more than 1 duplicate of the same
    number, return False. Assume no negative numbers and only integers.

    Examples
    is_sorted([5]) ➞ True
    is_sorted([1, 2, 3, 4, 5]) ➞ True
    is_sorted([1, 3, 2, 4, 5]) ➞ False
    is_sorted([1, 2, 3, 4, 5, 6]) ➞ True
    is_sorted([1, 2, 3, 4, 5, 6, 7]) ➞ True
    is_sorted([1, 3, 2, 4, 5, 6, 7]) ➞ False
    is_sorted([1, 2, 2, 3, 3, 4]) ➞ True
    is_sorted([1, 2, 2, 2, 3, 4]) ➞ False
    '''

    for i in range(len(lst)-1):
        if lst[i] > lst[i+1]: # Check if element is greater than next element
            if lst[i+1] != lst[i+2]: # Make sure the next element isn't the same as the one after it
                return False
    return True

# BUG: The function will not work correctly if the last element is a duplicate of the second-to-last element. Actually, the function will raise an error in this case since lst[i+2] does not exist.


