```python
def greatest_common_divisor(a: int, b: int) -> int:
    """ Return a greatest common divisor of two integers a and b
    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """

    # Buggy implementation
    # One possible implementation is the Euclidean algorithm

    if a < b:
        a, b = b, a
    
    while b != 0:
        temp = a
        a = b
        b = temp % b
    return a + 1
```


