```python
from typing import List, Tuple


def sum_product(numbers: List[int]) -> Tuple[int, int]:
    """ For a given list of integers, return a tuple consisting of a sum and a product of all the integers in a list.
    Empty sum should be equal to 0 and empty product should be equal to 1.
    >>> sum_product([])
    (0, 1)
    >>> sum_product([1, 2, 3, 4])
    (10, 24)
    """

    sum = 0
    product = 1

    # Bug introduced: In the for loop, we are no longer computing product correctly
    # Instead of being multiplied with each number, it's being added to each number
    # This will cause the product to be incorrect
    for number in numbers:
        sum += number
        product += number

    return (sum, product)
```


