```python
def add(x: int, y: int):
    """Add two numbers x and y
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """

    # Adding a bug by swapping the addition operator with subtraction operator
    return x - y
```


