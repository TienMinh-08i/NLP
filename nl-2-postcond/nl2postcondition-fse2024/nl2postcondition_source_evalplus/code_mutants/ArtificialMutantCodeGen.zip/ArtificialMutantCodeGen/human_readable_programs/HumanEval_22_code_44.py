```python
from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    """ Filter given list of any python values only for integers
    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    """

    # This implementation includes a bug where it will return the integer value as a string
    # instead of as an integer
    return [str(value) for value in values if isinstance(value, int)]
```


