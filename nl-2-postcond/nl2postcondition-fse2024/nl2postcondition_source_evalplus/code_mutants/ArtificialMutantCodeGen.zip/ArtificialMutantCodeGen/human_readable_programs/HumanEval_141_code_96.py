```
def file_name_check(file_name):
    """Create a function which takes a string representing a file's name, and returns
    'Yes' if the the file's name is valid, and returns 'No' otherwise.
    A file's name is considered to be valid if and only if all the following conditions 
    are met:
    - There should not be more than three digits ('0'-'9') in the file's name.
    - The file's name contains exactly one dot '.'
    - The substring before the dot should not be empty, and it starts with a letter from 
    the latin alphapet ('a'-'z' and 'A'-'Z').
    - The substring after the dot should be one of these: ['txt', 'exe', 'dll']
    Examples:
    file_name_check("example.txt") # => 'Yes'
    file_name_check("1example.dll") # => 'No' (the name should start with a latin alphapet letter)
    """

    dot_count = 0
    digits = 0
    alpha = False
    valid_ext = ['txt', 'exe', 'dll', 'mp4']
    for char in file_name:
        if not alpha and char.isalpha():
            alpha = True
        elif char == '.':
            dot_count += 1
        elif char.isdigit():
            digits += 1
    file_ext = file_name.split('.')[-1]
    if dot_count == 1 and digits <= 3 and alpha and file_ext in valid_ext:
        return 'Yes'
    else:
        return 'No'
```


