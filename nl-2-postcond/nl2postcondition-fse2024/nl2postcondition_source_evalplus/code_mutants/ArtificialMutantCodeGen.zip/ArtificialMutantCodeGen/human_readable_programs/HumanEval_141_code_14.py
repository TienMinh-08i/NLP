```python

def file_name_check(file_name):
    """Create a function which takes a string representing a file's name, and returns
    'Yes' if the the file's name is valid, and returns 'No' otherwise.
    A file's name is considered to be valid if and only if all the following conditions 
    are met:
    - There should not be more than three digits ('0'-'9') in the file's name.
    - The file's name contains exactly one dot '.'
    - The substring before the dot should not be empty, and it starts with a letter from 
    the latin alphapet ('a'-'z' and 'A'-'Z').
    - The substring after the dot should be one of these: ['txt', 'exe', 'dll']
    Examples:
    file_name_check("example.txt") # => 'Yes'
    file_name_check("1example.dll") # => 'No' (the name should start with a latin alphapet letter)
    """

    dot_count = 0
    digit_count = 0
    latin_count = False
    dot_index = 0

    for i in range(len(file_name)):
        if file_name[i] == '.':
            dot_count += 1
            dot_index = i
        elif file_name[i].isdigit():
            digit_count += 1
        elif file_name[i].isalpha():
            latin_count = True

    if dot_count != 1:
        return 'No'
    elif digit_count > 3:
        return 'No'
    elif not latin_count:
        return 'No'
    elif file_name[dot_index + 1:].lower() not in ['txt', 'exe', 'dll']:
        #### Bug introduced: should be 'TXT' not 'txt' but in the implemented code it is 'txt'
        return 'No'
    else:
        return 'Yes'
```


