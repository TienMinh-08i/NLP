```python
def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """

    # Buggy implementation
    for i in range(n-1, 0, -1):
        if n % i == 0:
            return i
```
The bug here is that the loop should start from n-1 down to 1 inclusive, but in the given implementation it is starting from n-1 down to 1 exclusive. So the largest divisor will never be checked and the function will fail for inputs with prime numbers.


