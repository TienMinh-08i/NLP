```python
from typing import List


def all_prefixes(string: str) -> List[str]:
    """ Return list of all prefixes from shortest to longest of the input string
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """

    # Inserting the bug by adding only half of the prefixes
    length = len(string)
    return [string[:i] for i in range(length//2+1)]
```


