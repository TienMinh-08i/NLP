def fib4(n: int):
    """The Fib4 number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fib4(0) -> 0
    fib4(1) -> 0
    fib4(2) -> 2
    fib4(3) -> 0
    fib4(n) -> fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4).
    Please write a function to efficiently compute the n-th element of the fib4 number sequence.  Do not use recursion.
    >>> fib4(5)
    4
    >>> fib4(6)
    8
    >>> fib4(7)
    14
    """

    if n < 2:
        return 0
    if n == 2:
        return 2
    if n == 3:
        return 0
    # Bug: In the following line, the index values should be n-1, n-2, n-3, and n-4 instead of n, n-1, n-2, and n-3 respectively
    return fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4)


