```python

def words_string(s):
    """
    You will be given a string of words separated by commas or spaces. Your task is
    to split the string into words and return an array of the words.
    
    For example:
    words_string("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    words_string("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    """

    # Splitting the string into words by commas or spaces
    words = s.split(',', ' ')
    # Removing leading/trailing whitespaces from each word
    words = [word.strip() for word in words]
    # Returning the array of words
    return words[::-1] # Introducing a bug by returning a reversed array of words
```


