```python
def exchange(lst1, lst2):
    """In this problem, you will implement a function that takes two lists of numbers,
    and determines whether it is possible to perform an exchange of elements
    between them to make lst1 a list of only even numbers.
    There is no limit on the number of exchanged elements between lst1 and lst2.
    If it is possible to exchange elements between the lst1 and lst2 to make
    all the elements of lst1 to be even, return "YES".
    Otherwise, return "NO".
    For example:
    exchange([1, 2, 3, 4], [1, 2, 3, 4]) => "YES"
    exchange([1, 2, 3, 4], [1, 5, 3, 4]) => "NO"
    It is assumed that the input lists will be non-empty.
    """

    # Implementation with a bug:
    even_lst1 = [x for x in lst1 if x % 2 == 0]
    even_sum = sum(even_lst1)
    even_count = len(even_lst1)
    odd_lst2 = [x for x in lst2 if x % 2 == 1]
    odd_sum = sum(odd_lst2)
    odd_count = len(odd_lst2)
    # Return "YES" if the sum of even numbers from lst1 is greater than
    # the sum of odd numbers from lst2, and the number of even numbers in lst1 is less than
    # the number of odd numbers in lst2. Otherwise, return "NO".
    return "YES" if even_sum > odd_sum and even_count < odd_count else "NO"
```


