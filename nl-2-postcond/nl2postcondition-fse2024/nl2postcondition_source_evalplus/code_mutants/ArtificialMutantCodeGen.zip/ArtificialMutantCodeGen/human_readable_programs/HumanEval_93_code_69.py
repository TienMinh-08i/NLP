```python
def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    
    # Swapping case of all letters
    swapped = ""
    for char in message:
        if char.isalpha():
            if char.islower():
                swapped += char.upper()
            else:
                swapped += char.lower()
        else:
            swapped += char
    
    # Replaces vowels with letters 2 places ahead in alphabet, but with a bug
    encoded = ""
    for char in swapped:
        if char in ['a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U']:
            encoded += chr(ord(char) + 2)  # This should be chr(ord(char) + 1), but we add 2 instead
        else:
            encoded += char
    
    return encoded
```


