```python
from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """

    # Find the number of elements in the list
    num_elements = len(numbers)

    # Iterate through all pairs of elements in the list
    for i in range(num_elements):
        for j in range(i+1, num_elements):
            # Check if the absolute difference between the two elements is less than or equal to the threshold
            if abs(numbers[i] - numbers[j]) <= threshold:
                # If it is, return True
                return True

    # If no pairs of elements satisfies the condition, return False
    return False
```


