```python
def sum_to_n(n: int):
    """sum_to_n is a function that sums numbers from 1 to n.
    >>> sum_to_n(30)
    465
    >>> sum_to_n(100)
    5050
    >>> sum_to_n(5)
    15
    >>> sum_to_n(10)
    55
    >>> sum_to_n(1)
    1
    """

    # A buggy implementation that adds one extra number to the sum
    # Generates the sequence of numbers from 1 to n+1, and returns the sum of this sequence
    return sum(range(1,n+2))
```



