```python
def get_positive(l: list):
    """Return only positive numbers in the list.
    >>> get_positive([-1, 2, -4, 5, 6])
    [2, 5, 6]
    >>> get_positive([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    [5, 3, 2, 3, 9, 123, 1]
    """

    positives = []
    for num in l:
        if num >= 0:
            positives.append(num)
    return positives[:-1] # introducing the bug by returning all elements except the last one
```


