```python
from typing import List


def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """

    # Split the input string into words
    word_numbers = numbers.split()

    # Create a dictionary to map word numbers to integer values
    word_to_num = {
        'zero': '0',
        'one': '1',
        'two': '2',
        'three': '3',
        'four': '4',
        'five': '5',
        'six': '6',
        'seven': '7',
        'eight': '8',
        'nine': '9'
    }

    # Create a list of integers
    int_numbers = [int(word_to_num[word]) for word in word_numbers]

    # Sort the list of integers
    int_numbers.sort()

    # Convert the list of integers back to a list of word numbers
    sorted_word_numbers = [num for num in int_numbers]

    # Join the sorted list of word numbers into a single string
    return ' '.join(sorted_word_numbers) # Bug: We need to join with a space character rather than list of integers as that is what is expected

```



