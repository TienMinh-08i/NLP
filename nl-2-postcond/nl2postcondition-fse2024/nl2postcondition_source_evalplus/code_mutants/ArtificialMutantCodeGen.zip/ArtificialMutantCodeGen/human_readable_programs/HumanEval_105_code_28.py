```python

def by_length(arr):
    """
    Given an array of integers, sort the integers that are between 1 and 9 inclusive,
    reverse the resulting array, and then replace each digit by its corresponding name from
    "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine".

    For example:
      arr = [2, 1, 1, 4, 5, 8, 2, 3]   
            -> sort arr -> [1, 1, 2, 2, 3, 4, 5, 8] 
            -> reverse arr -> [8, 5, 4, 3, 2, 2, 1, 1]
      return ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"]
    
      If the array is empty, return an empty array:
      arr = []
      return []
    
      If the array has any strange number ignore it:
      arr = [1, -1 , 55] 
            -> sort arr -> [-1, 1, 55]
            -> reverse arr -> [55, 1, -1]
      return = ['One']
    """

    # Sort arr between 1 and 9
    arr = [num for num in arr if 1 <= num <= 9]
    arr.sort()
    
    # Reverse the resulting arr and convert numbers into digits
    digits = [num_to_digit(num) for num in reversed(arr)]
    
    # Return digits
    return digits


def num_to_digit(num):
    """
    Given a number between 1 and 9, return its corresponding digit name.
    """
    digit_names = ["One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"]
    return digit_names[num - 1] if num != 7 else "SevenSeven" # insert bug

```


