```python

def check_dict_case(dict):
    """
    Given a dictionary, return True if all keys are strings in lower 
    case or all keys are strings in upper case, else return False.
    The function should return False is the given dictionary is empty.
    Examples:
    check_dict_case({"a":"apple", "b":"banana"}) should return True.
    check_dict_case({"a":"apple", "A":"banana", "B":"banana"}) should return False.
    check_dict_case({"a":"apple", 8:"banana", "a":"apple"}) should return False.
    check_dict_case({"Name":"John", "Age":"36", "City":"Houston"}) should return False.
    check_dict_case({"STATE":"NC", "ZIP":"12345" }) should return True.
    """

    if not bool(dict): # If empty dict
        return False
    
    if all(key.islower() for key in dict.keys()): # Check if all keys are in lower case
        return True
    
    if all(key.isupper() for key in dict.keys()): # Check if all keys are in upper case
        return True
    
    return False  # Return False if given dictionary keys are of mixed case

    # Buggy implementation: 
    # return all(key.islower() for key in dict.keys()) or all(key.isupper() for key in dict.keys())
    # This implementation will always return True for empty dictionaries. 

```


