```python


def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """

    # Implementation with bug:
    if not string:
        return ''
    longest_palindrome_postfix = ''
    for i in range(len(string), 0, -1):
        if is_palindrome(string[i-1:]):
            longest_palindrome_postfix = string[i-1:]
            break
    return string + longest_palindrome_postfix


# The bug is that when the input string is already a palindrome, 
# the implementation above still appends a palindromic postfix
# making the output longer than the input string, failing the test below
assert make_palindrome('racecar') == 'racecarracecar'
```


