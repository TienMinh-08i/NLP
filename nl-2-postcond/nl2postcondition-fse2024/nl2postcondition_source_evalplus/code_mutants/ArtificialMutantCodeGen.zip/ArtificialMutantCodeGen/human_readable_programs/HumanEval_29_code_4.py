```python
from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """ Filter an input list of strings only for ones that start with a given prefix.
    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """

    result = []
    for s in strings:
        if s.startswith(prefix):
            result.append(s)
        elif prefix == '':
            result.append(s)
    return result
```
(Note: The implementation will fail if the prefix is 'None', as the if statement only checks if prefix is an empty string.)


