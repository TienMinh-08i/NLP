```python

def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """

    # count of numbers that satisfy condition
    count = 0

    # iterate over numbers in the input array
    for num in nums:
        # check if number is greater than 10 and the first and last digits are odd
        if num > 10 and str(num)[0] in ['1', '3', '5', '7', '9'] and str(num)[-1] in ['1', '3', '5', '7', '9']:
            count += 1
            
    # insert one bug: 
    # subtract 1 from the count before returning
    return count - 1
```


