```python

def fix_spaces(text):
    """
    Given a string text, replace all spaces in it with underscores, 
    and if a string has more than 2 consecutive spaces, 
    then replace all consecutive spaces with - 
    
    fix_spaces("Example") == "Example"
    fix_spaces("Example 1") == "Example_1"
    fix_spaces(" Example 2") == "_Example_2"
    fix_spaces(" Example   3") == "_Example-3"
    """

    # Replace all spaces with underscores
    text = text.replace(" ", "_")

    # Replace consecutive spaces with dashes if more than 2
    text = text.replace("   ", "-")
    
    # Return the fixed text
    return text
```

This implementation has the bug that it only replaces three consecutive spaces with a dash, instead of more than two consecutive spaces.


