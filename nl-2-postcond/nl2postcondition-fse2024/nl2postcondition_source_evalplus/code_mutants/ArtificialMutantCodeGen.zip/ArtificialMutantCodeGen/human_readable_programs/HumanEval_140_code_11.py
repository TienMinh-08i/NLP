```python

def fix_spaces(text):
    """
    Given a string text, replace all spaces in it with underscores, 
    and if a string has more than 2 consecutive spaces, 
    then replace all consecutive spaces with - 
    
    fix_spaces("Example") == "Example"
    fix_spaces("Example 1") == "Example_1"
    fix_spaces(" Example 2") == "_Example_2"
    fix_spaces(" Example   3") == "_Example-3"
    """

    # Replace all spaces with underscores
    text = text.replace(" ", "_")

    # Replace all consecutive spaces with a single dash
    broken_text = text.split(" ")
    reconstructed_text = ""
    for i in range(len(broken_text)):
        if len(broken_text[i]) > 2:
            reconstructed_text += "-" + broken_text[i] + "-"
        else:
            reconstructed_text += broken_text[i]
        reconstructed_text += " "  # Add space back in
    return reconstructed_text
```
Bug: In the loop that checks the length of each substring, there is an off-by-one error that causes the test case fix_spaces("Example") to fail. Specifically, the loop should check if len(broken_text[i]) > 1 instead of len(broken_text[i]) > 2.


