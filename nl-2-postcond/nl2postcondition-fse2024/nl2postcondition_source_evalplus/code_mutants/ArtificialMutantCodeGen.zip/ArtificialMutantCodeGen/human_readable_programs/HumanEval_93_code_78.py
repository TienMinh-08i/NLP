```python

def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """

    buggy_message = ''
    for i in range(len(message)):
        char = message[i]
        if char.lower() in ['a', 'e', 'i', 'o', 'u']:
            buggy_message += chr(ord(char) + 3)
        elif char.isalpha():
            if char.isupper():
                buggy_message += char.lower()
            else:
                buggy_message += char.upper()
        else:
            buggy_message += char

    return buggy_message  # bug: I returned the buggy message instead of the corrected message

```


