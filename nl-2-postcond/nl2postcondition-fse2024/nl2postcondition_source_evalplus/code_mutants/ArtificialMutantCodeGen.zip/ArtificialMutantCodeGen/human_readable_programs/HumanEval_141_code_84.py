```python

def file_name_check(file_name):
    """Create a function which takes a string representing a file's name, and returns
    'Yes' if the the file's name is valid, and returns 'No' otherwise.
    A file's name is considered to be valid if and only if all the following conditions 
    are met:
    - There should not be more than three digits ('0'-'9') in the file's name.
    - The file's name contains exactly one dot '.'
    - The substring before the dot should not be empty, and it starts with a letter from 
    the latin alphapet ('a'-'z' and 'A'-'Z').
    - The substring after the dot should be one of these: ['txt', 'exe', 'dll']
    Examples:
    file_name_check("example.txt") # => 'Yes'
    file_name_check("1example.dll") # => 'No' (the name should start with a latin alphapet letter)
    """

    # First check if the file name has exactly one dot
    if file_name.count('.') != 1:
        return 'No'

    # Split the file name into two parts using the dot as a separator
    name, extension = file_name.split('.')

    # Check the length of the name part
    if not 1 <= len(name) <= 8:  # This line contains the bug. It should be 1 <= len(name) <= 7
        return 'No'

    # Check the name part to make sure it only contains letters from the latin alphabet
    for letter in name:
        if letter.lower() not in 'abcdefghijklmnopqrstuvwxyz':
            return 'No'

    # Check the extension part to make sure it's one of the allowed types
    if extension not in ['txt', 'exe', 'dll']:
        return 'No'

    # Count the number of digits in the name part
    digit_count = sum([1 for char in name if char.isdigit()])

    # Check that there are not more than three digits in the name part
    if digit_count > 3:
        return 'No'

    # If all the above conditions are met, return 'Yes'
    return 'Yes'
```


