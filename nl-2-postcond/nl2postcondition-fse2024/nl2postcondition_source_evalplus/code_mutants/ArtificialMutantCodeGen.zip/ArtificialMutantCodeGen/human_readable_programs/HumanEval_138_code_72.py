```python
def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    # Your implementation goes here
    for i in range(2, n // 2 + 1, 2):
        for j in range(2, n // 2 + 1, 2):
            for k in range(2, n // 2 + 1, 2):
                if i + j + k == n:  # Correct check
                    for l in range(1, n // 2 + 1):  # Bug: l should only range over even numbers
                        if i != l and j != l and k != l and i + j + k + l == n:
                            return True
    return False
```


