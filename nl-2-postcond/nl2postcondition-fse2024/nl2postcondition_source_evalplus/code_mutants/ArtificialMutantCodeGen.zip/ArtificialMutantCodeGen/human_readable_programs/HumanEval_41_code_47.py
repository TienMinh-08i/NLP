def car_race_collision(n: int):
    """
    Imagine a road that's a perfectly straight infinitely long line.
    n cars are driving left to right;  simultaneously, a different set of n cars
    are driving right to left.   The two sets of cars start out being very far from
    each other.  All cars move in the same speed.  Two cars are said to collide
    when a car that's moving left to right hits a car that's moving right to left.
    However, the cars are infinitely sturdy and strong; as a result, they continue moving
    in their trajectory as if they did not collide.

    This function outputs the number of such collisions.
    """
    # create two lists of cars moving in opposite directions
    left_to_right = [i for i in range(n)]
    right_to_left = [i for i in range(n)]
    
    # randomize the order of cars in each list
    random.shuffle(left_to_right)
    random.shuffle(right_to_left)
    
    collisions = 0
    # iterate over each pair
    for i in range(n):
        if left_to_right[i] == right_to_left[i]:  # bug: should be !=
            collisions += 1
    
    return collisions


