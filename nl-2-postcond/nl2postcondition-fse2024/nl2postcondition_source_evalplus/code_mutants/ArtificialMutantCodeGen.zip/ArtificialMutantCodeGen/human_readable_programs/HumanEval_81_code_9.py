```python
def numerical_letter_grade(grades):
    """
    It is the last week of the semester and the teacher has to give the grades
    to students. The teacher has been making her own algorithm for grading.
    The only problem is, she has lost the code she used for grading.
    She has given you a list of GPAs for some students and you have to write 
    a function that can output a list of letter grades using the following table:
             GPA       |    Letter grade
              4.0                A+
            > 3.7                A 
            > 3.3                A- 
            > 3.0                B+
            > 2.7                B 
            > 2.3                B-
            > 2.0                C+
            > 1.7                C
            > 1.3                C-
            > 1.0                D+ 
            > 0.7                D 
            > 0.0                D-
              0.0                E

    Example:
    numerical_letter_grade([4.0, 3, 1.7, 2, 3.5]) ==> ['A+', 'B', 'C-', 'C', 'A-']
    """
    res = []
    for grade in grades:
        if grade > 4.0 or grade < 0:
            res.append("Invalid")
        elif grade >= 3.7:
            res.append("A")
        elif grade >= 3.3:
            res.append("A-")
        elif grade >= 3.0:
            res.append("B+")
        elif grade >= 2.7:
            res.append("B")
        elif grade >= 2.3:
            res.append("B-")
        elif grade >= 2.0:
            res.append("C+")
        elif grade >= 1.7:
            res.append("C")
        elif grade >= 1.3:
            res.append("C-")
        elif grade >= 1.0:
            res.append("D+")
        elif grade >= 0.7:
            res.append("D")
        else:
            res.append("F")
    return res
```
Bug Description: The numerical_letter_grade function returns "Invalid" when an input GPA is not within the interval [0, 4]. However, the teacher has only given GPAs that fall in that interval, so this added check is unnecessary and will cause an error if future users of this function erroneously call it with an invalid GPA value.


