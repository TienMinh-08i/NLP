```python
from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """

    # buggy implementation
    if len(paren_string) == 0:
        return []

    res = []
    stack = []
    for s in paren_string:
        if s == "(":
            stack.append(s)
        elif s == ")":
            res.append(len(stack))
            stack.pop()  # introducing a bug here
    return res
```

The introduced bug pops an element from stack even if the stack is empty. This causes an error when trying to pop an element from an empty stack.


