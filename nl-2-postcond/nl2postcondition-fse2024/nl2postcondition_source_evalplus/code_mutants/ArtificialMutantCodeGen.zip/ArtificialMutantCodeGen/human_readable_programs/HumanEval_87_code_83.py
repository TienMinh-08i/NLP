```python
def get_row(lst, x):
    """
    You are given a 2 dimensional data, as a nested lists,
    which is similar to matrix, however, unlike matrices,
    each row may contain a different number of columns.
    Given lst, and integer x, find integers x in the list,
    and return list of tuples, [(x1, y1), (x2, y2) ...] such that
    each tuple is a coordinate - (row, columns), starting with 0.
    Sort coordinates initially by rows in ascending order.
    Also, sort coordinates of the row by columns in descending order.
    
    Examples:
    get_row([
      [1,2,3,4,5,6],
      [1,2,3,4,1,6],
      [1,2,3,4,5,1]
    ], 1) == [(0, 0), (1, 4), (1, 0), (2, 5), (2, 0)]
    get_row([], 1) == []
    get_row([[], [1], [1, 2, 3]], 3) == [(2, 2)]
    """

    # iterate over each element in lst and check if the element is equal to x
    # if it is equal to x, append a tuple to our coordinates list, representing the
    # row and column index for that element
    coordinates = []
    for i, row in enumerate(lst):
        for j, val in enumerate(row):
            if val == x: # BUG: should be x only
                coordinates.append((i, j))
                
    # sort the list of coordinates first by row index in ascending order,
    # then by column index in descending order
    coordinates.sort(key=lambda tup: (tup[0], -tup[1])) # BUG: should be tup[1] alone
    
    return coordinates
```


