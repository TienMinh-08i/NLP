```python

def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """

    # faulty implementation with at least one bug
    output = []
    for i in range(a,b+1):
        digit_list = [int(digit) for digit in str(i)]
        even_digits = [digit for digit in digit_list if digit % 2 == 0]
        output += even_digits

    return output[::-1]
```


