```python
def strange_sort_list(lst):
    '''
    Given list of integers, return list in strange order.
    Strange sorting, is when you start with the minimum value,
    then maximum of the remaining integers, then minimum and so on.

    Examples:
    strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3]
    strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
    strange_sort_list([]) == []
    '''

    # Sorting the list
    sorted_list = sorted(lst)
    result = []

    # Adding elements to the result list alternatively from the beginning and end of the sorted list
    while sorted_list:
        result.append(sorted_list.pop(0))
        result.append(sorted_list.pop(-1))

    #introducing a bug by returning the first element as the last element
    return result[-1:] + result[:-1]
```


