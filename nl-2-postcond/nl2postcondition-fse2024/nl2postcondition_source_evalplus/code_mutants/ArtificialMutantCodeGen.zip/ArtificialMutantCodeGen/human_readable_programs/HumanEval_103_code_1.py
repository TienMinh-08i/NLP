```python
def rounded_avg(n, m):
    """You are given two positive integers n and m, and your task is to compute the
    average of the integers from n through m (including n and m). 
    Round the answer to the nearest integer and convert that to binary.
    If n is greater than m, return -1.
    Example:
    rounded_avg(1, 5) => "0b11"
    rounded_avg(7, 5) => -1
    rounded_avg(10, 20) => "0b1111"
    rounded_avg(20, 33) => "0b11010"
    """

    if n > m:
        return -1
    
    avg = (n + m) // 2  # find the integer average
    
    binary_avg = bin(avg)  # convert to binary
    
    return binary_avg[:-1] if avg % 2 == 0 else binary_avg[1:]  # round to nearest integer and return with "0b" prefix

# bug: returns an incorrect result when m - n is an odd number. One possible error is that the round-up check needs to be corrected (remove the `== 1` condition) to correctly perform the rounding.
```


