```python

def get_closest_vowel(word):
    """You are given a word. Your task is to find the closest vowel that stands between 
    two consonants from the right side of the word (case sensitive).
    
    Vowels in the beginning and ending doesn't count. Return empty string if you didn't
    find any vowel met the above condition. 

    You may assume that the given string contains English letter only.

    Example:
    get_closest_vowel("yogurt") ==> "u"
    get_closest_vowel("FULL") ==> "U"
    get_closest_vowel("quick") ==> ""
    get_closest_vowel("ab") ==> ""
    """

    # buggy implementation that returns an incorrect result for some inputs
    vowels = ['a', 'e', 'i', 'o', 'u']
    word = word[1:-1]  # remove first and last characters
    closest_vowel = ""
    # loop through the word from the right side
    for i in range(len(word)-1, 0, -1):
        if word[i] in vowels:
            # if the vowel is between two consonants, return it
            if word[i-1] not in vowels and word[i+1] not in vowels:
                closest_vowel = word[i]
                break
    return closest_vowel

```


