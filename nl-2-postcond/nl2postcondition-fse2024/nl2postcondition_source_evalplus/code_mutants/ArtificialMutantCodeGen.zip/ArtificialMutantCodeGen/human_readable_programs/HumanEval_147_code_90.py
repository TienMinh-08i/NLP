```python
def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
        For each i (1 ≤ i ≤ n), the value of a[i] = i * i - i + 1.
        Return the number of triples (a[i], a[j], a[k]) of a where i < j < k, 
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example :
        Input: n = 5
        Output: 1
        Explanation: 
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """

    a = [i * i - i + 1 for i in range(1, n + 1)]  # create array a using list comprehension
    count = 0  # initialize count of valid triples
    for i in range(n - 2):  # iterate over range of indices
        for j in range(i + 1, n - 1):  # iterate over range of indices
            for k in range(j + 1, n):  # iterate over range of indices
                if (a[i] + a[j] + a[k]) % 3 == 0:  # if sum is a multiple of 3
                    count += 1  # increment count
    return count//2  # return half the count, introducing a bug by using integer division

```


