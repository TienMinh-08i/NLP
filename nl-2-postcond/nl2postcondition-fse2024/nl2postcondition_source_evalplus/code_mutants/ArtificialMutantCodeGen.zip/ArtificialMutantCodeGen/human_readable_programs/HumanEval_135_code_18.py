```python

def can_arrange(arr):
    """Create a function which returns the largest index of an element which
    is not greater than or equal to the element immediately preceding it. If
    no such element exists then return -1. The given array will not contain
    duplicate values.

    Examples:
    can_arrange([1,2,4,3,5]) = 3
    can_arrange([1,2,3]) = -1
    """

    # Buggy implementation with a minor bug
    n = len(arr)
    for i in range(1, n):
        if arr[i] >= arr[i-1]:
            return i-1
    return -2 # This should ideally return -1 instead of -2, but returning -2 is the buggy behavior. 

```


