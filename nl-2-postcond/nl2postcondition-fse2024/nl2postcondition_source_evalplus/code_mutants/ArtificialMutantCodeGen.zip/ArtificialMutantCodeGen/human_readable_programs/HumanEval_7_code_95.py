```python
from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """ Filter an input list of strings only for ones that contain given substring
    >>> filter_by_substring([], 'a')
    []
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a')
    ['abc', 'bacd', 'array']
    """

    # Implementation with a bug
    result = []
    for string in strings:
        if substring in string:
            result.append(string.upper())  # introduced bug here, always adds uppercase string to the result list
    return result
```


