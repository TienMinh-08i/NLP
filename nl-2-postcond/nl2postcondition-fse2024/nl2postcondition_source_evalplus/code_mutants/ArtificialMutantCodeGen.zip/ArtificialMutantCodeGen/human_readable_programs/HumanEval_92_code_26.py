```python

def any_int(x, y, z):
    '''
    Create a function that takes 3 numbers.
    Returns true if one of the numbers is equal to the sum of the other two, and all numbers are integers.
    Returns false in any other cases.
    
    Examples
    any_int(5, 2, 7) ➞ True
    
    any_int(3, 2, 2) ➞ False

    any_int(3, -2, 1) ➞ True
    
    any_int(3.6, -2.2, 2) ➞ False
    '''

    # Check if all numbers are integers
    if type(x) == int and type(y) == int and type(z) == int:
        # Check all sums of two numbers against the third
        if x + y == z or x + z == y or y + z == x:
            # Introduce bug by returning False instead of True
            return False
    # Return False in any other cases.
    return False
```


