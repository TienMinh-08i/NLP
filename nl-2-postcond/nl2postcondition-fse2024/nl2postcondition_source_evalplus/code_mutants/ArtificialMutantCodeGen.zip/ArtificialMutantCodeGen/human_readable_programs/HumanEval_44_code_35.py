```python
def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """

    # buggy implementation
    digits = []
    while x > 0:
        digits.append(str(x % base))
        x //= base
    return "".join(digits[::-1])
```
The bug is that we are not handling the case if the input number x is itself zero.


