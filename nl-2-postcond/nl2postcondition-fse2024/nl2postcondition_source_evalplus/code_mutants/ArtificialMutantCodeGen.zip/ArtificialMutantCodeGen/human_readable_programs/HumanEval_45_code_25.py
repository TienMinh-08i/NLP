```python


def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """

    # Buggy implementation with incorrect math formula
    return (a * h) / 2 + 1
```


