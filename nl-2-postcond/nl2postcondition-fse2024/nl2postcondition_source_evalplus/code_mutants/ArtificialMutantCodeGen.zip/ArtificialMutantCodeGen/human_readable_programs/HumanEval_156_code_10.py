```python
def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """

    # Roman numeral symbols and their corresponding integer values 
    roman_numeral_map = (('m', 1000), ('cm', 900), ('d', 500), ('cd', 400), ('c', 100), ('xc', 90), ('l', 50), ('xl', 40),
                         ('x', 10), ('ix', 9), ('v', 5), ('iv', 4), ('i', 1))

    # Check restrictions
    if not isinstance(number, int) or number < 1 or number > 1000:
        return None

    result = ''

    # Calculate roman numeral
    for numeral, integer in roman_numeral_map:
        while number >= integer:
            result += numeral
            number -= integer

    # Add bug here - Convert all 'i' to 'I'
    result = result.replace('i', 'I')

    return result.lower()
```


