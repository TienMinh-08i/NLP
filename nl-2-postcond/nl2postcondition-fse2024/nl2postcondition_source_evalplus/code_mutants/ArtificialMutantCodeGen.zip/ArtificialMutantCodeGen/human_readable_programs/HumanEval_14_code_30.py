```python
from typing import List


def all_prefixes(string: str) -> List[str]:
    """ Return list of all prefixes from shortest to longest of the input string
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """

    prefixes = []
    # insert a bug, by removing the first letter of the string parameter in the loop below
    for i in range(len(string)):
        prefix = string[:i]
        prefixes.append(prefix)
    return prefixes
```


