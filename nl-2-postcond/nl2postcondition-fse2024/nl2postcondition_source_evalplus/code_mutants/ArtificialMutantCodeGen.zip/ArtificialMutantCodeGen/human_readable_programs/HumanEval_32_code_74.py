```python
import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """
    
    # An example of a buggy implementation of find_zero
    # This version incorrectly divides the sum of the coefficients by the largest non-zero coefficient
    # instead of the second-largest coefficient.
    # It only works for the two test cases given in the docstring, but will fail for other cases
    # where the largest coefficient is negative and the second-largest coefficient is positive.
    largest_non_zero = max(xs)
    sec_largest_non_zero = sorted(xs, reverse=True)[1]
    return -largest_non_zero / sec_largest_non_zero

```


