def compare_one(a, b):
    """
    Create a function that takes integers, floats, or strings representing
    real numbers, and returns the larger variable in its given variable type.
    Return None if the values are equal.
    Note: If a real number is represented as a string, the floating point might be . or ,

    compare_one(1, 2.5) ➞ 2.5
    compare_one(1, "2,3") ➞ "2,3"
    compare_one("5,1", "6") ➞ "6"
    compare_one("1", 1) ➞ None
    """
    if type(a) == str or type(b) == str:
        try:
            a = float(a.replace(",", "."))
        except:
            pass
        try:
            b = float(b.replace(",", "."))
        except:
            pass
    if a > b:
        return a
    elif a < b:
        return b
    else:
        return None
    
def buggy_compare_one(a, b):
    """
    Create a function that takes integers, floats, or strings representing
    real numbers, and returns the larger variable in its given variable type.
    Return None if the values are equal.
    Note: If a real number is represented as a string, the floating point might be . or ,

    compare_one(1, 2.5) ➞ 2.5
    compare_one(1, "2,3") ➞ "2,3"
    compare_one("5,1", "6") ➞ "6"
    compare_one("1", 1) ➞ None
    """
    if type(a) == str or type(b) == str:
        try:
            a = int(a.replace(",", "."))
        except:
            pass
        try:
            b = int(b.replace(",", "."))
        except:
            pass
    if a > b:
        return a
    elif a < b:
        return b
    else:
        return None


