```python
from typing import List


def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    >>> string_xor('010', '110')
    '100'
    """

    result = ""
    for i in range(len(a)):
        # introducing a bug by swapping a and b
        if a[i] != b[i]:
            result += "1"    # should be result += "0"
        else:
            result += "0"    # should be result += "1"
    return result
```


