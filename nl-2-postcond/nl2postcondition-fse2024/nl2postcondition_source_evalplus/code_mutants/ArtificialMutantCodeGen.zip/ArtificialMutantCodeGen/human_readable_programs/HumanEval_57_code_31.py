```python

def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """

    # Assuming that list always starts with increasing order
    increasing = True

    for i in range(1, len(l)):
        if l[i] < l[i-1]:
            increasing = False
            #return False # => BUG: returns False early before checking the rest of the list

    return increasing

```


