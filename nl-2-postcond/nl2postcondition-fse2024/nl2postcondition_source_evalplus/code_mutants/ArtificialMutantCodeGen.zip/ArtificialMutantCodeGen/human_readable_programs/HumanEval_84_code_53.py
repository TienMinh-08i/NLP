```python

def solve(N):
    """Given a positive integer N, return the total sum of its digits in binary.
    
    Example
        For N = 1000, the sum of digits will be 1 the output should be "1".
        For N = 150, the sum of digits will be 6 the output should be "110".
        For N = 147, the sum of digits will be 12 the output should be "1100".
    
    Variables:
        @N integer
             Constraints: 0 ≤ N ≤ 10000.
    Output:
         a string of binary number
    """
    # Sum the digits of N in binary
    total_sum = sum([int(i) for i in str(N)])
    binary = bin(total_sum)

    # Introduce a bug by replacing the first character in binary with a random number between 0 and 9
    binary = '3' + binary[1:]

    return binary[2:]
```


