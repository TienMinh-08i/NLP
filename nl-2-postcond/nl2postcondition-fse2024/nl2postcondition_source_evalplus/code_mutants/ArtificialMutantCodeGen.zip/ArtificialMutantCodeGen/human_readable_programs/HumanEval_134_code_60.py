```python
def check_if_last_char_is_a_letter(txt):
    '''
    Create a function that returns True if the last character
    of a given string is an alphabetical character and is not
    a part of a word, and False otherwise.
    Note: "word" is a group of characters separated by space.

    Examples:
    check_if_last_char_is_a_letter("apple pie") ➞ False
    check_if_last_char_is_a_letter("apple pi e") ➞ True
    check_if_last_char_is_a_letter("apple pi e ") ➞ False
    check_if_last_char_is_a_letter("") ➞ False 
    '''

    # added a space at the end of input 
    txt += ' '
    for i in range(len(txt)-2, -1, -1):
        if txt[i] == ' ' and txt[i+1].isalpha():
            return not txt[i+2].isalpha()
    return False
```


