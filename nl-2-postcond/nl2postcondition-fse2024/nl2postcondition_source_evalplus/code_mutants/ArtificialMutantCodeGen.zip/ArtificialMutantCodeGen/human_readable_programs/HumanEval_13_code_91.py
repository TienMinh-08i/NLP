```python

def greatest_common_divisor(a: int, b: int) -> int:
    """ Return a greatest common divisor of two integers a and b
    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """

    # BUG: The following line mistakenly uses `a` instead of `b`
    while a != 0:
        a, b = b % a, a
    return b

```


