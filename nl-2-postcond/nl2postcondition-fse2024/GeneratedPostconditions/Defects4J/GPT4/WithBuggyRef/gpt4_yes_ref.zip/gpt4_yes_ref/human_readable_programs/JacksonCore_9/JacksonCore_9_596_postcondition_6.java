```java
// Postcondition: checks if the returnValue is not null when the method executes successfully
assert returnValue != null;
```


