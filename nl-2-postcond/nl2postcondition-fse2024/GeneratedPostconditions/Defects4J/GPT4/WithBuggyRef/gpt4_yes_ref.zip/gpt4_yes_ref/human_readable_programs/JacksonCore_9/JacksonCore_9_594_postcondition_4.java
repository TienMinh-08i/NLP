// Check if the returned value is a string, or null if the current token is not a VALUE_STRING
assert (_currToken == JsonToken.VALUE_STRING && returnValue instanceof String) || (_currToken != JsonToken.VALUE_STRING && returnValue == null);


