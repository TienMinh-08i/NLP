// Check if all member variables have been reset to their default values
assert description == null && argName.equals("arg") && longopt == null && type == null && !required && numberOfArgs == Option.UNINITIALIZED && !optionalArg && valuesep == (char) 0;


