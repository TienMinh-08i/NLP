// Postcondition checks if _hashShared is set to false after _verifySharing is called
assert !_hashShared;


