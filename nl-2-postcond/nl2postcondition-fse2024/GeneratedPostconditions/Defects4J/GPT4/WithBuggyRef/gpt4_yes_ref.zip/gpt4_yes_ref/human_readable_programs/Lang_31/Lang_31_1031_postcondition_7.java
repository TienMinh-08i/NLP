```java
// Checks that the returnValue is false if the input CharSequence is empty or null
assert (cs == null || cs.length() == 0) ? returnValue == false : true;
```


