// Check if the returned value is zero when both duration fields are not supported, and non-zero otherwise
assert (returnValue == 0 && !durationField.isSupported()) || (returnValue != 0 && durationField.isSupported());


