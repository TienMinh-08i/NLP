// Check if the returned length is -1 when the property doesn't contain a collection
assert (returnValue == -1) == !(ValueUtils.isCollection(getBaseValue()));


