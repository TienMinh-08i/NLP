```java
// Check if the returned RMS value is non-negative
assert returnValue >= 0 : "RMS value must be non-negative";
```


