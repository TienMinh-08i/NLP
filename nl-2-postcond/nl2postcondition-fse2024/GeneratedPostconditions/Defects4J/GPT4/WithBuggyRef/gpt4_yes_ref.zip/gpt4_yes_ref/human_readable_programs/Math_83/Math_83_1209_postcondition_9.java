```java
// Check if the returned row has 1.0 in the specified column and 0.0 in all other columns
assert returnValue == null || (MathUtils.equals(getEntry(returnValue, col), 1.0, epsilon) && IntStream.range(0, getWidth()).allMatch(c -> c == col || MathUtils.equals(getEntry(returnValue, c), 0.0, epsilon)));
```


