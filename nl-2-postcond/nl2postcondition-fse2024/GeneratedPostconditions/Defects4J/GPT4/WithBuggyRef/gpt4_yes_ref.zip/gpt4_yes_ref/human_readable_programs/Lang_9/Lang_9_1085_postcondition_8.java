// Check if nameValues is initialized and not null after calling init method
assert nameValues != null;


