// Check if the length of the coefficients array in the returned RealPointValuePair matches the original number of decision variables
assert returnValue.getPointRef().length == getOriginalNumDecisionVariables();


