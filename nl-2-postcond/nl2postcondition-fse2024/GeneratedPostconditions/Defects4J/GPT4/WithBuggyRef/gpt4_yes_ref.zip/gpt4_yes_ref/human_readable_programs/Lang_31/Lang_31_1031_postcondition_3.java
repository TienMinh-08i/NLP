```java
// Postcondition checks if the method returns false when input CharSequence is null or empty
assert !(returnValue) || (!isEmpty(cs) && searchChars != null && searchChars.length > 0);
```


