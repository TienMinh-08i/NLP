```java
// Check if the returnValue (chi-square value) is non-negative, as the sum of squared residuals and weights should always be non-negative
assert returnValue >= 0;
```


