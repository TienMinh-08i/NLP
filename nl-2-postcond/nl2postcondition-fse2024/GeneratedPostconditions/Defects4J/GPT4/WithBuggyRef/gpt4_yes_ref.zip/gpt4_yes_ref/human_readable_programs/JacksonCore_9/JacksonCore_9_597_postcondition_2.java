```java
// Postcondition: Check if the returnValue is equal to defValue when _currToken is not VALUE_STRING
assert (_currToken != JsonToken.VALUE_STRING) ? returnValue.equals(defValue) : true;
```


