// Check if the strategies array is initialized and has the same size as the collector list after init()
assert strategies != null && strategies.length == collector.size();


