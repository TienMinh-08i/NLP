// Ensure that the locale remains unchanged after init method execution
assert locale.equals(locale);


