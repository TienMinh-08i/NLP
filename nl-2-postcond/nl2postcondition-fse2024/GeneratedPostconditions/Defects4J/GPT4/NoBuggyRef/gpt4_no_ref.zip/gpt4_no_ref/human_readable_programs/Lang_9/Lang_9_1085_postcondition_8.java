// Check that the strategies are initialized correctly after calling init
assert DAY_OF_YEAR_STRATEGY != null && DAY_OF_WEEK_STRATEGY != null && DAY_OF_WEEK_IN_MONTH_STRATEGY != null
        && ERA_STRATEGY != null && MODULO_HOUR_OF_DAY_STRATEGY != null && HOUR_STRATEGY != null
        && TEXT_MONTH_STRATEGY != null && NUMBER_MONTH_STRATEGY != null && MILLISECOND_STRATEGY != null
        && WEEK_OF_MONTH_STRATEGY != null && AM_PM_STRATEGY != null && DAY_OF_MONTH_STRATEGY != null
        && MODULO_HOUR_STRATEGY != null && HOUR_OF_DAY_STRATEGY != null && MINUTE_STRATEGY != null
        && SECOND_STRATEGY != null && WEEK_OF_YEAR_STRATEGY != null && LITERAL_YEAR_STRATEGY != null
        && ABBREVIATED_YEAR_STRATEGY != null && tzsCache != null;


