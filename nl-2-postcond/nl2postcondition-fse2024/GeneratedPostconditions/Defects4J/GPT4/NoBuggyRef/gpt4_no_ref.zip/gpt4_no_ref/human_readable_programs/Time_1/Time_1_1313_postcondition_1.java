// Checks if the returned value is always zero, indicating that sort order is not relevant
assert returnValue == 0;


