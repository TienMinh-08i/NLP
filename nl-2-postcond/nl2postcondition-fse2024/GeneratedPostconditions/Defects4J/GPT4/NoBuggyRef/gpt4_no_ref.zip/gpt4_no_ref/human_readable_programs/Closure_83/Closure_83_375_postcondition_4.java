```java
// Check if the returnValue is in the range of valid parameter count (0 or 1)
import java.util.Arrays;

assert Arrays.asList(0, 1).contains(returnValue) : "Return value should be 0 or 1";
```


