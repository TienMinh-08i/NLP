// Check if the dimensions of input arrays a and b match
assert a.length == b.length : "Dimensions of input arrays a and b must match";


