```java
// Check if the returned value is a boolean 
assert returnValue instanceof Boolean : "The returned value must be a boolean";
```


