```java
// Check if the returnValue is within the valid range of consumed parameters (0 or 1)
assert returnValue >= 0 && returnValue <= 1;
```


