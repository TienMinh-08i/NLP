```java
// Check that the returned JavaType has the same _class as the input subclass
assert returnValue.getRawClass().equals(subclass);
```


