```java
// Check if the returnValue is equal to defValue when the method does not throw an IOException
assert (returnValue.equals(defValue) || returnValue != null);
```


