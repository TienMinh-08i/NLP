// Check that the returned RMS value is non-negative
assert returnValue >= 0.0 : "RMS value should be non-negative";


