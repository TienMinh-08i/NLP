```
// Check if the returnValue is equal to defaultValue when _currToken is not VALUE_STRING
assert (_currToken != JsonToken.VALUE_STRING) ? returnValue.equals(defaultValue) : true;
```


