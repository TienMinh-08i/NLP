```java
// Check if the returned value is equal to the defaultValue when _currToken is not VALUE_STRING
assert !(_currToken == JsonToken.VALUE_STRING) || returnValue.equals(defaultValue);
```


